package mypkg.FilnalProject1;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login 
{

	public static void main(String[] args) throws IOException 
	{
		FileInputStream fis= new FileInputStream("C:\\Users\\DELL\\Desktop\\ExcellSheet\\FinalProject1");
		XSSFWorkbook book = new XSSFWorkbook(fis);		
		XSSFSheet sh1= book.getSheet("Sheet1");
		XSSFSheet sh2= book.getSheet("Sheet2");

		System.setProperty("webdriver.chrome.driver","C:\\Users\\DELL\\Desktop\\drivers\\chromedriver.exe");
		WebDriver wb=new ChromeDriver();
		wb.get("http://demo.guru99.com/test/newtours/"); 
		wb.manage().window().maximize();
	
		System.out.println("Login with Valid credentials");
		
		for(int i=1; i<=sh1.getLastRowNum(); i++)
		{
			String username=sh1.getRow(i).getCell(0).toString();
			String password=sh1.getRow(i).getCell(1).toString();	 
			System.out.println(username+" "+password);
		
			wb.findElement(By.name("username")).sendKeys(username);
			wb.findElement(By.name("password")).sendKeys(password);
			wb.findElement(By.name("submit")).click();

			if(wb.getTitle().equalsIgnoreCase("Login: Mercury Tours"))
			{
				System.out.println("Test Case Passed");
			}
			else
			{
				System.out.println("Test Case Failed");
			}
				try
				{
					wb.findElement(By.linkText("SIGN-OFF")).click();		
				}		
				catch(Exception e)
				{
					System.out.println("Invalid credentials at row no.:"+i);					
				}	
		
				
		}	
				
				System.out.println("Login with Invalid credentials");
				
				for(int i=1; i<=sh2.getLastRowNum(); i++)
				{
					String username=sh2.getRow(i).getCell(0).toString();
					String password=sh2.getRow(i).getCell(1).toString();	 
					System.out.println(username+" "+password);
				
					wb.findElement(By.name("username")).sendKeys(username);
					wb.findElement(By.name("password")).sendKeys(password);
					wb.findElement(By.name("submit")).click();

					if(wb.getTitle().equalsIgnoreCase("Login: Mercury Tours"))
					{
						System.out.println("Test Case Passed");
					}
					else
					{
						System.out.println("Test Case Failed");
					}
						try
						{
							wb.findElement(By.linkText("SIGN-OFF")).click();		
						}		
						catch(Exception e)
						{
							System.out.println("Invalid credentials at row no.:"+i);					
						}		
				}
	}

}
