package mypkg.FilnalProject1;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
public class Registration 
{
	public static void main(String[] args) throws IOException 
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\DELL\\Desktop\\drivers\\chromedriver.exe");
		WebDriver wb=new ChromeDriver();
		wb.get("http://demo.guru99.com/test/newtours/"); 
		wb.manage().window().maximize();
		wb.findElement(By.name("username")).sendKeys("test1");
		wb.findElement(By.name("password")).sendKeys("test1");
		wb.findElement(By.name("submit")).click();
		FileInputStream fis=new FileInputStream("C:\\Users\\DELL\\Desktop\\ExcellSheet\\FinalProject1");
		XSSFWorkbook book=new XSSFWorkbook(fis);
		XSSFSheet sh=book.getSheet("Sheet1");
		XSSFSheet sh1=book.getSheet("Sheet2");
		System.out.print("no of record"+sh.getLastRowNum());
		
		for(int i=1; i<=sh.getLastRowNum();i++)
		{
			String Firstname=sh.getRow(i).getCell(0).toString();
			String Lastname=sh.getRow(i).getCell(1).toString();
			String Phone=sh.getRow(i).getCell(2).toString();
			String Email=sh.getRow(i).getCell(3).toString();
			String Address=sh.getRow(i).getCell(4).toString();
			String City=sh.getRow(i).getCell(5).toString();
			String State=sh.getRow(i).getCell(6).toString();
			String PostalCode=sh.getRow(i).getCell(7).toString();
			String Country=sh.getRow(i).getCell(8).toString();
			String UserName=sh.getRow(i).getCell(9).toString();
			String Password=sh.getRow(i).getCell(10).toString();
			String ConfirmPassword=sh.getRow(i).getCell(11).toString();
		
			wb.findElement(By.name("firstname")).sendKeys(Firstname);
			wb.findElement(By.name("lastname")).sendKeys(Lastname);
			wb.findElement(By.name("phone")).sendKeys(Phone);
			wb.findElement(By.name("username")).sendKeys(Email);
			wb.findElement(By.name("address1")).sendKeys(Address);
			wb.findElement(By.name("city")).sendKeys(City);
			wb.findElement(By.name("State")).sendKeys(State);
			wb.findElement(By.name("PostalCode")).sendKeys(PostalCode);
			Select count=new Select(wb.findElement(By.name("country")));
			
			count.selectByVisibleText(Country);
			wb.findElement(By.name("email")).sendKeys(UserName);
			wb.findElement(By.name("password")).sendKeys("Password");
			wb.findElement(By.name("confirmPassword")).sendKeys("confirmPassword");
			wb.findElement(By.name("submit")).click();
			
			if(wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/register_sucess.php"))
			{
				System.out.println("Registration passed");
				wb.findElement(By.linkText("REGISTER")).click();
			}
			else
			{
				System.out.println("Registration failed");
				wb.findElement(By.linkText("REGISTER")).click();
			}
		}
		System.out.println("No of record :"+sh1.getLastRowNum());
		for(int i=1; i<=sh1.getLastRowNum();i++)
		{
			String Firstname=sh1.getRow(i).getCell(0).toString();
			String Lastname=sh1.getRow(i).getCell(1).toString();
			String Phone=sh1.getRow(i).getCell(2).toString();
			String Email=sh1.getRow(i).getCell(3).toString();
			String Address=sh1.getRow(i).getCell(4).toString();
			String City=sh1.getRow(i).getCell(5).toString();
			String State=sh1.getRow(i).getCell(6).toString();
			String PostalCode=sh1.getRow(i).getCell(7).toString();
			String Country=sh1.getRow(i).getCell(8).toString();
			String UserName=sh1.getRow(i).getCell(9).toString();
			String Password=sh1.getRow(i).getCell(10).toString();
			String ConfirmPassword=sh1.getRow(i).getCell(11).toString();
			
			wb.findElement(By.name("firstname")).sendKeys(Firstname);
			wb.findElement(By.name("lastname")).sendKeys(Lastname);
			wb.findElement(By.name("phone")).sendKeys(Phone);
			wb.findElement(By.name("username")).sendKeys(Email);
			wb.findElement(By.name("address1")).sendKeys(Address);
			wb.findElement(By.name("city")).sendKeys(City);
			wb.findElement(By.name("State")).sendKeys(State);
			wb.findElement(By.name("PostalCode")).sendKeys(PostalCode);
			Select count1=new Select(wb.findElement(By.name("country")));
			
			count1.selectByVisibleText(Country);
			wb.findElement(By.name("email")).sendKeys(UserName);
			wb.findElement(By.name("password")).sendKeys("Password");
			wb.findElement(By.name("confirmPassword")).sendKeys("confirmPassword");
			wb.findElement(By.name("submit")).click();
		
			if(wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/register_sucess.php"))
			{
				System.out.println("Registration passed");
				wb.findElement(By.linkText("REGISTER")).click();
			}
			else
			{
				System.out.println("Registration failed");
				wb.findElement(By.linkText("REGISTER")).click();
		}	
	}
}
}
