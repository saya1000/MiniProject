package mypkg.FilnalProject1;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class Linktest 
{
	WebDriver wb;
  @Test
  public void f() throws InterruptedException 
  {
	  wb.findElement(By.linkText("Hotels")).click();
	  Thread.sleep(2000);
	  String hote=wb.getTitle();
	  if(hote.contains("Under Construction")||wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/index.php"))
	  {
		  System.out.println(wb.findElement(By.xpath("//tbody/tr[3]/td[1]/p[1]/front[1]/b[1]/front[1]")).getText());
		  System.out.println(wb.findElement(By.xpath("//front[contains(text(),'for any inconvience.')]")).getText());
	  }
	  else
	  {
		  System.out.println("page is working");
	  }
	  
	  //...........
	  
	  wb.findElement(By.linkText("Car Rentals")).click();
	  Thread.sleep(2000);
	  String Rentals=wb.getTitle(); 
	  if(Rentals.contains("Under Construction")||wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/index.php"))
	  {
		  System.out.println(wb.findElement(By.xpath("//tbody/tr[3]/td[1]/p[1]/front[1]/b[1]/front[1]")).getText());
		  System.out.println(wb.findElement(By.xpath("//front[contains(text(),'for any inconvience.')]")).getText());
	  }
	  else
	  {
		  System.out.println("pageis working");
	  }
	  
	  //..........
	  
	 
	  wb.findElement(By.linkText("Cruises")).click();
	  Thread.sleep(2000);
	  String cru=wb.getTitle();	 
	  if(cru.contains("Under Construction")||wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/index.php"))
	  {
		  System.out.println(wb.findElement(By.xpath("//tbody/tr[3]/td[1]/p[1]/front[1]/b[1]/front[1]")).getText());
		  System.out.println(wb.findElement(By.xpath("//front[contains(text(),'for any inconvience.')]")).getText());
	  }
	  else
	  {
		  System.out.println("pageis working");
	  }
	  
	  //...........
	  
	  wb.findElement(By.linkText("Destinations")).click();
	  Thread.sleep(2000);
	  String dest=wb.getTitle();
	  if(dest.contains("Under Construction")||wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/index.php"))
	  {
		  System.out.println(wb.findElement(By.xpath("//tbody/tr[3]/td[1]/p[1]/front[1]/b[1]/front[1]")).getText());
		  System.out.println(wb.findElement(By.xpath("//front[contains(text(),'for any inconvience.')]")).getText());
	  }
	  else
	  {
		  System.out.println("pageis working");
	  }
	  
	  //............
	  
	  wb.findElement(By.linkText("Vacations")).click();
	  Thread.sleep(2000);
	  String vac=wb.getTitle();
	  if(vac.contains("Under Construction")||wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/index.php"))
	  {
		  System.out.println(wb.findElement(By.xpath("//tbody/tr[3]/td[1]/p[1]/front[1]/b[1]/front[1]")).getText());
		  System.out.println(wb.findElement(By.xpath("//front[contains(text(),'for any inconvience.')]")).getText());
	  }
	  else
	  {
		  System.out.println("pageis working");
	  }
	  
	 //............
	  wb.findElement(By.linkText("SUPPORT")).click();
	  Thread.sleep(2000);
	  String sup=wb.getTitle();
	  if(sup.contains("Under Construction")||wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/index.php"))
	  {
		  System.out.println(wb.findElement(By.xpath("//tbody/tr[3]/td[1]/p[1]/front[1]/b[1]/front[1]")).getText());
		  System.out.println(wb.findElement(By.xpath("//front[contains(text(),'for any inconvience.')]")).getText());
	  }
	  else
	  {
		  System.out.println("pageis working");
	  }
 
	  //............
	  
	  wb.findElement(By.linkText("CONTACT")).click();
	  Thread.sleep(2000);
	  String con=wb.getTitle();
	  if(con.contains("Under Construction")||wb.getCurrentUrl().equals("http://demo.guru99.com/test/newtours/index.php"))
	  {
		  System.out.println(wb.findElement(By.xpath("//tbody/tr[3]/td[1]/p[1]/front[1]/b[1]/front[1]")).getText());
		  System.out.println(wb.findElement(By.xpath("//front[contains(text(),'for any inconvience.')]")).getText());
	  }
	  else
	  {
		  System.out.println("pageis working");
	  }	  
  } 
  @BeforeClass
  public void beforeClass() 
  {
	  System.setProperty("webdriver.chrome.driver","C:\\Users\\DELL\\Desktop\\drivers\\chromedriver.exe");
		WebDriver wb=new ChromeDriver();
		wb.get("http://demo.guru99.com/test/newtours/"); 
		wb.manage().window().maximize();	  
   }

  @AfterClass
  public void afterClass() 
  {
	  wb.close();
  }

}
